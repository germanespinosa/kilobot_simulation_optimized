$pi=3.141592
$radius = 18
$diameter = 2 * $radius
$time = 6000 #1 hour 40 minutes

$sursin= $pi * [math]::pow($radius,2) /2

$f = convertfrom-csv (cat shape.cfg -first 1) -Header "disks,bases,figurex,figurey,scale,thickness".split(",")
$d = convertfrom-csv (cat shape.cfg -first (($f.disks -as [int])+1) | select -skip 1) -Header "x,y,priority,size,delay".split(",")

while ($i -lt 100)
{
	$i=$i+1
	$s=Get-Date;
	.\kilobot_simulation.exe /d n /l n /t $time /f run-$i.log 
	$e=Get-Date; 
	$totaltime = ($e - $s).TotalSeconds
	$l = ConvertFrom-Csv -Header "time,type,id,x,y,state,seed,disk,hopcount".Split(",") (cat run-$i.log | select-string basic )
	$r = $l | where {$_.state -eq 3}
	$s = $r|where{$_.seed -eq 'true'}
	$avgpack =  0
	$dcount=0
	$d | ForEach-Object { 
		if (($s | where {$_.disk -eq $dcount}) -ne $null)
		{
			$count=0 ;
			$t1 = $f.thickness -as [int]
			$t2 = $_.size -as [int]
			$tolerance = $t1*$t2*$diameter;
			$surdisk= $pi * [math]::pow($tolerance,2) / 2;
			$x1 = $f.figurex -as [float]; 
			$x2 = $f.scale -as [float];
			$x3 = $_.x -as [float];
			$diskx= $x1+$x2*$x3;
			$y1=$f.figurey -as [float];
			$y2=$f.scale -as [float];
			$y3=$_.y -as [float];
			$disky = $y1+ $y2 * $y3; 
			$r | ForEach-Object {
				$dist = [math]::pow([math]::pow($diskx - $_.x,2)+[math]::pow($disky - $_.y,2),.5);
				if ($dist -le $tolerance)
				{
					$count = $count + 1
				}
			}
			$packing = $count * $sursin / $surdisk * 100
			$avgpack = $avgpack + $packing
		}
		$dcount = $dcount + 1
	}
	$avgpack = [math]::Round($avgpack/$dcount,2)
	$pr = [math]::Round(( $r.Count / $l.Count ) * 100,2)
	$pd = [math]::Round((($s|select disk -unique).Count / $f.disks ) * 100,2)
	echo "run-$i $totaltime seconds, %$pd disks formed, %$pr robots recruited, %$avgpack average circle packing"
	echo "$i, $totaltime, $pd, $pr, $avgpack" >> results.log
}